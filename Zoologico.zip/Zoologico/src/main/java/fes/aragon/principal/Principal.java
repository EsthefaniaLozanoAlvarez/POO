/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fes.aragon.principal;

import fes.aragon.Felinos;
import fes.aragon.Tigre;

/**
 *
 * @author Esthefania
 */
public class Principal {
    public static void main(String[] args) {
        Felinos fel=new Felinos(new Tigre("Tiger",50.8f,10), 9);
        System.out.println(fel);
    }
            
}
