/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fes.aragon;

/**
 *
 * @author Esthefania
 */
public class Felinos {
    Tigre tigre;
    private int noJaula;

    public Felinos(Tigre tigre, int noJaula) {
        this.tigre = tigre;
        this.noJaula = noJaula;
    }

    public Tigre getTigre() {
        return tigre;
    }

    public void setTigre(Tigre tigre) {
        this.tigre = tigre;
    }

    public int getNoJaula() {
        return noJaula;
    }

    public void setNoJaula(int noJaula) {
        this.noJaula = noJaula;
    }

    @Override
    public String toString() {
        return "tigre=" + tigre + ", noJaula=" + noJaula;
    }
    
    
}
